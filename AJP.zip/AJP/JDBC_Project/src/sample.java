import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class sample {
    public static void main(String[]args) {
        try {
            Class.forName("com.mysql.jdbc.driver.");
            Connection con=DriverManager.getConnection("jdbc:mysql://@localhost","root","");
            Statement smt=con.createStatement();
            smt.executeUpdate("Create table emp2(eno number,ename varchar(12),esal number)");
            System.out.print("Table Created");
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

}
