import java.awt.*;

class b_t extends Frame {
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9;
    b_t(){
        setLayout(new GridLayout(3,3,5,5));
        setTitle("Button 1 To 9");
        setSize(300,300);
        setVisible(true);
        b1=new Button("b1"); add(b1);
        b2=new Button("b2"); add(b2);
        b3=new Button("b3"); add(b3);
        b4=new Button("b4"); add(b4);
        b5=new Button("b5"); add(b5);
        b6=new Button("b6"); add(b6);
        b7=new Button("b7"); add(b7);
        b8=new Button("b8"); add(b8);
        b9=new Button("b9"); add(b9);
    }
    public static void main(String []args){
        new b_t();
    }
}