import javax.swing.*;
import javax.xml.transform.Result;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Balance_inquiry extends JFrame implements ActionListener {
    JLabel j1,j2;
    JTextField t1,t2;
    JButton b1;
    Balance_inquiry() {
        j1 = new JLabel("Enter Account Number");
        j1.setBounds(10, 50, 150, 20);
        add(j1);
        t1 = new JTextField();
        t1.setBounds(160, 50, 150, 25);
        add(t1);
        b1 = new JButton("Submit");
        b1.setBounds(100, 110, 120, 20);
        b1.addActionListener(this);
        add(b1);
        setTitle("Balance_inquiry");
        setLayout(null);
        setSize(350, 350);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ac){
        String AccountNumber; AccountNumber=t1.getText();
        if (ac.getSource()==b1)
        try {
           conn c=new conn();
           String q="select * from bank where AccountNumber='"+AccountNumber+"' ";

    }
    public static void main(String[]args){
        new Balance_inquiry();
    }
}

