import java.applet.Applet;
import java.awt.*;

public class L_10 extends Applet {
    //List l1;
    public void init(){
       List l1=new List(5,true);  add(l1);
        l1.add("India");
        l1.add("Pakistan");
        l1.add("Bangladesh");
        l1.add("Sri Lanka");
        l1.add("Afghanistan");
    }
}
