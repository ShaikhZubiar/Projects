import java.applet.Applet;
import java.awt.*;
public class Grid_demo extends Applet {
    Label l1,l2,l3,l4;
    TextField t1,t2,t3;
    TextArea ta;
    Button b1;
    public void init(){
        setLayout(new GridLayout(5,2,3,3));
        l1=new Label("Username"); add(l1);
        t1=new TextField(); add(t1);
        l2=new Label("Password"); add(l2);
        t2=new TextField(); t2.setEchoChar('*'); add(t2);
        l3=new Label("Email id"); add(l3);
        t3=new TextField(); add(t3);
        l4=new Label("Address");  add(l4);
        ta=new TextArea(5,5); add(ta);
        b1=new Button("Submit"); add(b1);
        setSize(350,250);

    }
}
