import java.applet.Applet;
import java.awt.*;
public class prr extends Applet {
    List l1,l2;
    public void init(){
        l1=new List();  add(l1);
        l1.add("bfsabdcjs");
        l1.add("sfcscf");
        l1.add("sfcasdc");
        l1.add("scascasx");
        l1.add("fasca");
        l1.add("gcgcghgh");
    }
}