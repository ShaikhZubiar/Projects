import java.awt.*;
import java.applet.Applet;
public class form extends Applet {
    Label l1,l2,l3;
    TextField t1,t2;
    TextArea a1;
    Button b1;
    public void init() {
        setLayout(null);
        l1=new Label("Username"); l1.setBounds(30,20,70,10);      add(l1);
        t1=new TextField(12); t1.setBounds(100,15,100,20);        add(t1);
        l2=new Label("Password");  l2.setBounds(30,60,70,30);         add(l2);
        t2=new TextField(12);   t2.setBounds(100,65,100,20);        add(t2);
        l3=new Label("Address");  l3.setBounds(30,120,75,20);         add(l3);
        a1=new TextArea(20,30); a1.setBounds(110,120,100,100);      add(a1);
        b1=new Button("Submit"); b1.setBounds(130,240,50,30);           add(b1);

    }
}
