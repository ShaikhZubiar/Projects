import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class check_output extends JFrame implements ActionListener {
    CardLayout card;
    JButton b1,b2,b3;
    Container c;
    check_output(){
        c=getContentPane();
        card=new CardLayout(40,30);
        c.setLayout(card);
        b1=new JButton("Computer");    b1.addActionListener(this);           c.add("a",b1);
        b2=new JButton("Motherboard");  b2.addActionListener(this);          c.add("b",b2);
        b3=new JButton("Mouse");        b3.addActionListener(this);          c.add("c",b3);

    }
    public void actionPerformed(ActionEvent e){
        card.next(c);
    }
    public static void main(String []args){
        check_output xyz = new check_output();
        xyz.setSize(300,300);
        xyz.setVisible(true);
        xyz.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}
