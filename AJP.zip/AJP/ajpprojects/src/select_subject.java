import java.applet.Applet;
import java.awt.*;
public class select_subject extends Applet {
    Choice c1,c2;
    Label l1;
    public void init(){
        c1=new Choice(); add(c1);
        c2=new Choice(); add(c2);
        c1.add("C++");
        c1.add("JAVA");
        c1.add("Python");
        c1.add("CPP");
        c2.add("Physics");
        c2.add("Chemistry");
        c2.add("Maths");
        setLayout(new FlowLayout(FlowLayout.CENTER,20,20));
        l1=new Label("Select Subjects You Like"); add(l1);
    }

}
