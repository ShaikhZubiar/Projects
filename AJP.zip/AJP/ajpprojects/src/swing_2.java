public class swing_2 {
}
