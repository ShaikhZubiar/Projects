import java.awt.*;
    public class menu_bar extends Frame {
        menu_bar(){
            MenuBar m1=new MenuBar();
            setMenuBar(m1);
            Menu Color=new Menu("Color"); m1.add(Color);
            MenuItem White = new MenuItem("White"); Color.add(White);
            MenuItem Black = new MenuItem("Black"); Color.add(Black);
            Black.setEnabled(false);
            MenuItem Red=new MenuItem("Red"); Color.add(Red);
            MenuItem Green=new MenuItem("Green"); Color.add(Green);
            setSize(300,300); setVisible(true);
        }
        public static void main(String[]args){
            new menu_bar();
        }
}
