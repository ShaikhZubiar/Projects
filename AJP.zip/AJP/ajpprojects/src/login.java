import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class login extends JFrame implements ActionListener {
    JLabel j1, j2;
    JTextField t1, t2;
    JButton b1;

    login() {
        j1 = new JLabel("Username");
        j1.setBounds(50, 40, 60, 20);
        add(j1);
        t1 = new JTextField();
        t1.setBounds(140, 40, 90, 20);
        add(t1);
        j2 = new JLabel("Password");
        j2.setBounds(50, 80, 60, 20);
        add(j2);
        t2 = new JTextField();
        t2.setBounds(140, 80, 90, 20);
        add(t2);
        b1 = new JButton("Login");
        b1.setBounds(100, 160, 70, 20);
        add(b1);
        b1.addActionListener(this);
        setSize(300, 300);
        setLayout(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String userValue = t1.getText();
        String passValue = t2.getText();
        if (userValue.equals("123") && passValue.equals("123")) {
            bank_page page1 = new bank_page();
        } else {
            JOptionPane.showMessageDialog(this, "Enter Correct Username Or Password");
        }
    }
}
class l1
{

    public static void main(String arg[])
    {
        try
        {

            login form = new login();

        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}
