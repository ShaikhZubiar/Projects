import java.awt.*;
import java.awt.event.KeyEvent;

public class menu_with_shortcut extends Frame {
    menu_with_shortcut(){
        MenuBar m1=new MenuBar();
        setMenuBar(m1);
        Menu File=new Menu("File"); m1.add(File);
        MenuItem New=new MenuItem("New"); File.add(New);
        File.add(new MenuItem("Open"));
        File.add(new MenuItem("Save As")); File.addSeparator();
        MenuShortcut s1=new MenuShortcut(KeyEvent.VK_X);
        MenuItem Exit=new MenuItem("Exit",s1); File.add(Exit);
        setSize(300,300);
        setVisible(true);


    }
    public static void main(String[]args){
        new menu_with_shortcut();
    }
}
