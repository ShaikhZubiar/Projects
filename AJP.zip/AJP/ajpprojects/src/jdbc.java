import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class jdbc {
    public static void main(String[]args) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bankdatabase","root","");
            Statement smt=con.createStatement();
            smt.executeUpdate("Create table bank3(euid varchar(20) ,ename varchar(20),efathername varchar(20),emobile varchar(20),ebal varchar(20),eaccount varchar(20))");
            System.out.print("Table Created");
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

}
