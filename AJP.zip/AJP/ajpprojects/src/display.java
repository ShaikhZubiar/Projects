import java.awt.*;
public class display {
    display(){
        Frame f=new Frame("JAVA");
        f.setTitle("Display Massage");
        f.setLayout(null);
        Label l1=new Label("Welcome Java");
        Checkbox c1=new Checkbox("Mumbai"); f.add(c1);

        l1.setBounds(100,50,100,50);
        f.add(l1);
        f.setSize(300,300);
        f.setVisible(true);



    }
    public static void main(String args[])
    {
        display dis=new display();
    }
}
