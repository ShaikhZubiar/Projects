import java.awt.*;
public class multiple extends Frame {
    Checkbox c1,c2,c3;
    multiple(){
        setLayout(new FlowLayout());
        setTitle("Create Three Button");
        c1=new Checkbox("Hindi"); add(c1);
        c2=new Checkbox("Urdu");  add(c2);
        c3=new Checkbox("English"); add(c3);
        setSize(300,300);
        setVisible(true);

    }
    public static void main(String[] args)
    {
        new multiple();
    }
}
