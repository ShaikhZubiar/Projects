import java.awt.*;
import java.applet.*;
public class rc extends Applet {
    Checkbox c1,c2,c3,c4,c5,c6,c7;
    Checkbox c8,c9;
    CheckboxGroup xyz;
    public void init()
    {
        c1 = new Checkbox("EST",true);
        c2 = new Checkbox("OSY",true);
        c3 = new Checkbox("AJP",true);
        c4 = new Checkbox("EST",true);
        c5 = new Checkbox("CSS");
        c6 = new Checkbox("ACN");
        c7 = new Checkbox("AMD");


        add(c1);
        add(c2);
        add(c3);
        add(c4);
        add(c5);
        add(c6);
        add(c7);

        xyz = new CheckboxGroup();
        c8 = new Checkbox("Male",xyz,true);
        c9 = new Checkbox("Female",xyz,false);
        add(c8);
        add(c9);



    }

}