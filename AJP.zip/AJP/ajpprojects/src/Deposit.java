import javax.swing.*;
import java.awt.*;

public class Deposit extends JFrame {
    JLabel j1,j2;
    JTextField t1,t2;
    JButton b1;
    Deposit(){
        j1=new JLabel("Enter Account Number"); j1.setBounds(10,50,150,20);
        add(j1);
        t1=new JTextField(); t1.setBounds(160,50,150,25); add(t1);
        j2=new JLabel("Enter Deposit Amount"); j2.setBounds(10,100,150,30);
        add(j2);
        t2=new JTextField(); t2.setBounds(160,100,110,25); add(t2);
        b1 = new JButton("Withdrawal");
        b1.setBounds(100, 160, 120, 20);
        add(b1);


        setLayout(null);
        setSize(350,350);
        setVisible(true);
    }
    public static void main(String[]args){
        new Deposit();
    }
}
