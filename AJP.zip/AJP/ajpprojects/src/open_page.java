import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.Objects;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class open_page extends JFrame implements ActionListener {
    JLabel j1, j2, j3, j4;
    JTextField t1, t2, t3, t4;
    JButton b1;
    Random r1;
    String AccountNumber;

    open_page() {
        JLabel header = new JLabel("Account Opening Form");
        header.setBounds(95, 20, 180, 20);
        header.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(header);
        j1 = new JLabel("Enter Aadhaar Number");
        j1.setBounds(10, 60, 130, 20);
        add(j1);
        t1 = new JTextField();
        t1.setBounds(150, 60, 100, 20);
        t1.setBackground(new Color(204, 255, 255));
        add(t1);
        j2 = new JLabel("Enter Name");
        j2.setBounds(10, 100, 100, 20);
        add(j2);
        t2 = new JTextField();
        t2.setBounds(120, 100, 180, 20);
        t2.setBackground(new Color(204, 255, 255));
        add(t2);
        j3 = new JLabel("Enter Father Name");
        j3.setBounds(10, 140, 120, 20);
        add(j3);
        t3 = new JTextField();
        t3.setBounds(120, 140, 180, 20);
        t3.setBackground(new Color(204, 255, 255));
        add(t3);
        j4 = new JLabel("Enter Mobile Number");
        j4.setBounds(10, 180, 120, 20);
        add(j4);
        t4 = new JTextField();
        t4.setBounds(135, 180, 120, 20);
        t4.setBackground(new Color(204, 255, 255));
        add(t4);
        b1 = new JButton("Submit");
        b1.setBounds(135, 230, 120, 20);
        b1.addActionListener(this);
        add(b1);
        setLayout(null);
        setSize(400, 400);
        setVisible(true);

        r1 = new Random();
        int  start=1;
        int end=10000;
        int result=r1.nextInt(end-start)+start;
        AccountNumber = String.valueOf(result);
    }
    public void actionPerformed(ActionEvent a){
        String AadharNumber,Name,FatherName,MobileNumber;
        AadharNumber=t1.getText();Name=t2.getText();FatherName=t3.getText();MobileNumber=t4.getText();
        if (a.getSource() == b1) {
            if (AadharNumber.equals("") || Name.equals("") || FatherName.equals("") || MobileNumber.equals("")){
                JOptionPane.showMessageDialog(null,"Field Should Not Be Empty");
            }
            else {
                conn c=new conn();
                int ballance=0;
                String q="insert into bank values('"+AadharNumber+"','"+Name+"','"+FatherName+"','"+MobileNumber+"','"+AccountNumber+"','"+ballance+"')";
                try {
                    c.s.executeUpdate(q);
                    JOptionPane.showMessageDialog(null,"data inserted successfully");
                    JOptionPane.showMessageDialog(null,"Your Account Number Is:"+AccountNumber);
                }
                catch (SQLException ex){
                    Logger.getLogger(open_page.class.getName()).log(Level.SEVERE,null,ex);
                }
            }

        }


    }
    public static void main(String[]args){
        new open_page();
    }
}