import java.awt.*;

public class la_bel extends Frame {
    la_bel(String s) {
        super(s);
        setLayout(null);
        setVisible(true);
        setSize(500, 300);
        Label l1 = new Label("Label One");
        Label l2 = new Label("Label Two");
        Label l3 = new Label("Label Three");
        l1.setBounds(50, 50, 100, 100);
        l2.setBounds(150, 50, 100, 100);
        l3.setBounds(250, 50, 100, 100);
        add(l1);
        add(l2);
        add(l3);
    }
    public static void main(String args[]) {
        la_bel f = new la_bel("Demonstrating Frame");
    }
}
