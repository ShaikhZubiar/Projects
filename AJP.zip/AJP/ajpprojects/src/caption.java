import java.awt.*;

public class caption extends Frame {
    Button b1,b2,b3;
    caption(){
        setLayout(new FlowLayout());
        setSize(300,300);
        setVisible(true);
        b1=new Button("OK");    add(b1);
        b2=new Button("Reset"); add(b2);
        b3=new Button("Cancel");    add(b3);
    }
    public static void main(String args[])
    {
    new caption();
    }
}
