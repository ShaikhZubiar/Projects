import javax.swing.*;
import java.awt.*;

public class swing_3 extends JApplet {
    public void init(){
        setSize(200,200);
        JTextArea t1=new JTextArea(1,1);
        JScrollPane pane=new JScrollPane(t1); add(pane);
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        pane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    }
}
