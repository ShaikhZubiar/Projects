import java.applet.Applet;
import java.awt.*;

public class border_button extends Applet {
    Button l1,l2,l3,l4,l5;
    public void init(){
        setLayout(new BorderLayout(5,5));
        l1=new Button("North"); add("North",l1);
        l2=new Button("South");  add(l2,BorderLayout.SOUTH);
        l3=new Button("East");   add(l3,BorderLayout.EAST);
        l4=new Button("West");   add(l4,BorderLayout.WEST);
        l5=new Button("Center"); add(l5,BorderLayout.CENTER);
        setSize(280,150);
    }
}

