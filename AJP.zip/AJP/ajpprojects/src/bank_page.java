import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class bank_page extends JFrame implements ActionListener {
    JButton j1, j2, j3, j4;

    bank_page() {
        j1 = new JButton("Account Opening");
        j1.setBounds(50, 100, 150, 30);
        j1.addActionListener(this);
        add(j1);
        j2 = new JButton("Withdrawal");
        j2.setBounds(50, 150, 150, 30);
        j2.addActionListener(this);
        add(j2);
        j3 = new JButton("Deposit");
        j3.addActionListener(this);
        j3.setBounds(50, 200, 150, 30);
        add(j3);
        j4 = new JButton("Balance Inquiry");
        j4.addActionListener(this);
        j4.setBounds(50, 250, 150, 30);
        add(j4);
        setLayout(null);
        setSize(400, 400);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource() == j1){
            open_page p1=new open_page();
        }
        if(ae.getSource() == j2){
            with_drawal p2=new with_drawal();
        }
        if (ae.getSource() ==j3){
            Deposit p3=new Deposit();
        }
        if (ae.getSource() ==j4) {
            Balance_inquiry p3 = new Balance_inquiry();
        }



    }
    public static void main(String[]args){
        new bank_page();
    }
}








