import java.applet.Applet;
import java.awt.*;

public class pr4_1 extends Applet {
    public void init(){
        Button b1=new Button("One"); add(b1);
        Button b2=new Button("Two");
        Button b3=new Button("Three");

    }
}
