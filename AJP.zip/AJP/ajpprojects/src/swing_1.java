import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class swing_1 extends JApplet implements ItemListener {
    JLabel j1;
    public void init(){
        setLayout(null);
        j1=new JLabel();  j1.setBounds(170,100,150,20); add(j1);
        setSize(300,200);
        String Subject[]={"C++","JAVA","ACN","PYTHON","C"};
        JComboBox jb=new JComboBox(Subject); add(jb); jb.addItemListener(this);
        jb.setBounds(50,100,100,20);
}
public void itemStateChanged(ItemEvent b){
String stateName = (String) b.getItem();
j1.setText("You are Selected " +stateName);
    }
}