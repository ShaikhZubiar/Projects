import java.awt.*;
import java.applet.Applet;
public class trail extends Applet {
    Checkbox c1,c2,c3,c4;
    Checkbox c5,c6,c7;
    CheckboxGroup grp;

    public void init()
    {
        c1=new Checkbox("EST");         add(c1);
        c2=new Checkbox("OSY");         add(c2);
        c3=new Checkbox("AJP");         add(c3);
        c4=new Checkbox("STE");         add(c4);

        grp=new CheckboxGroup();
        c5=new Checkbox("CSS",grp,false);   add(c5);
        c6=new Checkbox("ACN",grp,true);   add(c6);
        c7=new Checkbox("ADM",grp,false);   add(c7);



    }
}
