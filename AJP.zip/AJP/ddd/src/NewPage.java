import javax.swing.*;
import java.awt.*;

//create NewPage class to create a new page on which user will navigate
class NewPage extends JFrame
{
    //constructor
    NewPage()
    {
        setDefaultCloseOperation(javax.swing.
                WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Welcome");
        setSize(400, 200);
    }
}